<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect input data
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $job_title = $_POST['job_title'];
    $employment_type = $_POST['employment_type'];
    $work_location = $_POST['work_location'];
    $education = $_POST['education'];
    $field_of_study = $_POST['field_of_study'];
    $certifications = $_POST['certifications'];
    $experience = $_POST['experience'];
    $previous_jobs = $_POST['previous_jobs'];
    $skills = $_POST['skills'];
    $availability = $_POST['availability'];
    $salary = $_POST['salary'];

    // Prepare the data to be written
    $data = "Full Name: $full_name\nEmail: $email\nPhone: $phone\nCity: $city\nJob Title: $job_title\nEmployment Type: $employment_type\nWork Location: $work_location\nEducation: $education\nField of Study: $field_of_study\nCertifications: $certifications\nExperience: $experience\nPrevious Jobs: $previous_jobs\nSkills: $skills\nAvailability: $availability\nSalary: $salary\n\n";

    // Write the data to the file
    file_put_contents('requests.txt', $data, FILE_APPEND);

    // Redirect back to the form page with a success message
    header("Location: Thankyou.html?success=1");
    exit();
}
?>

