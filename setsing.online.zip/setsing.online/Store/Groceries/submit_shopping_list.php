<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $items = $_POST['items'];
    $file = fopen("shopping_list.txt", "a");

    foreach ($items as $item) {
        fwrite($file, $item . PHP_EOL);
    }

    fclose($file);

    // Redirect to thank you page
    header("Location: thank_you.html");
    exit();
}
?>
