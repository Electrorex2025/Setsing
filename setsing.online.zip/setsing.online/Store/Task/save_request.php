<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from the form
    $name = htmlspecialchars($_POST['name']);
    $contact = htmlspecialchars($_POST['contact']);
    $description = htmlspecialchars($_POST['description']);

    // Define the path to the requests file
    $file_path = 'Requests.txt';

    // Create the data string
    $data = "Name: $name\nContact: $contact\nDescription: $description\n\n";

    // Write the data to the file
    file_put_contents($file_path, $data, FILE_APPEND | LOCK_EX);

    // Send the response
    echo "<html><body>";
    echo "<h1>Request Submitted</h1>";
    echo "<p>Thank you for your request. We will get back to you soon.</p>";
    echo "<a href='index.html'>Go back to the form</a>";
    echo "</body></html>";
}
?>
